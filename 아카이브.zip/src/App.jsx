import { useEffect } from "react";
import "./App.scss";
import { useDispatch } from "react-redux";
import { fetchMultiplePokemonById } from "./RTK/thunk";
import { Link, Route, Routes } from "react-router-dom";
import Detail from "./pages/Detail";
import Main from "./pages/Main";
import Search from "./pages/Search";
import Favorite from "./pages/Favorite";

function App() {
  // 상태 업데이트 하기 위해서 dispatch 해주기
  const dispatch = useDispatch();
  // 전달이 잘 되는지 확인

  useEffect(() => {
    // 만든 thunk함수 사용해 요청보내기
    dispatch(fetchMultiplePokemonById(151));
  }, []);

  return (
    <>
      <h1 className="text-[40px] text-center">포켓몬 도감</h1>
      <nav className="flex gap-[10px] justify-center">
        <Link to={"/"}>메인</Link>
        <Link to={"/detail/1"}>상세정보</Link>
        <Link to={"/search"}>검색</Link>
        <Link to={"/favorite"}>찜목록</Link>
      </nav>
      <main className="flex justify-center">
        <Routes>
          <Route path={"/"} element={<Main />} />
          <Route path={"/detail/:pokmon"} element={<Detail />} />
          <Route path={"/search"} element={<Search />} />
          <Route path={"/favorite"} element={<Favorite />} />
        </Routes>
      </main>
    </>
  );
}

export default App;
