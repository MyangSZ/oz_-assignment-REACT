export default function Favorite() {
  return <div>Favorite</div>;
}
