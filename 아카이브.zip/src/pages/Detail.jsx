export default function Detail() {
  return <div>Detail</div>;
}
